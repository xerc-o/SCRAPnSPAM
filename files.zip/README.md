# Form Automator (Playwright)

Tool 3 fase untuk automasi pengisian form: scraping struktur form → konfigurasi
mode isian via GUI → eksekusi loop submit + logging hasil.

> **PENTING — Etika & Legal**
> Gunakan tool ini **hanya** pada target yang sudah kamu punya izin eksplisit
> untuk diuji (scope pentest resmi, lab internal, atau aplikasi milik sendiri).
> Tool ini murni scraping struktur form + auto-fill data uji — tidak melakukan
> bypass otentikasi atau eksploitasi apapun. Kamu bertanggung jawab penuh atas
> penggunaannya.

## Instalasi

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
playwright install chromium

# Kalau python3-tk belum ada (Linux):
sudo apt install python3-tk
```

## Alur Pemakaian

### Fase 1 — Scraping

```bash
# Target public, tanpa login
python3 scraper.py --url "https://target.com/form" --output config.json

# Target butuh login manual dulu
python3 scraper.py --url "https://target.com/form" --login --output config.json
```

Browser akan terbuka (headful jika `--login`), kamu login manual, tekan ENTER
di terminal untuk lanjut scraping. Hasil: `config.json` berisi daftar field
(name, id, type, label, options, selector, dll) + selector tombol submit.

### Fase 2 — Konfigurasi GUI

```bash
python3 gui.py --config config.json
```

- Tab **Fields**: klik "Configure" per field, pilih mode isian:
  - `fixed` — nilai tetap (misal nama selalu "USER")
  - `random_string` — panjang custom (min-max), charset custom
    (alnum/letters/upper/lower/digits/custom), plus prefix & suffix teks tetap
    (misal suffix `@gmail.com`, atau prefix `"batam, "`)
  - `random_int` — range custom, atau jumlah digit tetap
  - `sequential` — counter naik tiap run (`user1`, `user2`, ...), bisa zero-pad
  - `wordlist` — pilih random baris dari file `.txt`, bisa ditambah prefix/suffix
  - `random_choice` — khusus select/radio/checkbox, pilih opsi random dari yang tersedia
  - `skip` — field dilewati
- Tab **Run Settings**:
  - Jumlah run (angka atau endless)
  - Session mode: context baru tiap run / reuse
  - Login required (kalau ya, runner akan buka browser headful & jeda login manual sekali, sesi disimpan ke `auth_state.json`)
  - Delay mode: none / fixed / random (min-max) / smart (delay otomatis memanjang kalau ada kegagalan beruntun)
  - Auto-detect hasil submit (cari keyword sukses/gagal umum) + override manual pakai CSS selector sukses/error

Klik **Simpan Konfigurasi** → hasil ke `field_config.json`.

### Fase 3 — Eksekusi

```bash
python3 runner.py --config field_config.json

# Override cepat tanpa buka GUI ulang:
python3 runner.py --config field_config.json --count 50
python3 runner.py --config field_config.json --count endless   # stop dengan Ctrl+C
```

Log hasil tiap run tersimpan otomatis ke `logs/run_log_<timestamp>.csv`
(kolom: run, timestamp, result, detail, status_code, + semua field yang diisi).

## Format nilai random_string

```
hasil = [prefix] + random(charset, panjang_acak) + [suffix]
```

Contoh:
- charset=alnum, panjang 7-9, suffix=`@gmail.com` → `xk29abcQ@gmail.com`
- charset=custom(`abcdef123`), panjang 4, prefix=`batam, ` → `batam, efa1`

## Catatan Teknis

- Deteksi submit button otomatis dari scraper (`button[type=submit]`,
  `input[type=submit]`, atau `<button>` tanpa type); kalau tidak ketemu,
  runner fallback ke `Enter` key.
- Radio/checkbox: mode `fixed` pakai `fixed_value` sebagai value opsi yang
  dicentang; mode `random_choice` pilih acak dari opsi yang terdeteksi saat scraping.
- File `auth_state.json` (cookies/session hasil login) tersimpan di folder kerja —
  hapus manual kalau mau login ulang dari awal.
