#!/usr/bin/env python3
"""
runner.py - Fase 3: Eksekusi loop pengisian & submit form otomatis.

PENTING (etika/legal): Jalankan HANYA terhadap target yang sudah diotorisasi
secara eksplisit untuk pengujian (scope pentest resmi / lab milik sendiri).
"""

import argparse
import csv
import json
import random
import time
from datetime import datetime
from pathlib import Path

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

import generators

SUCCESS_HINTS = ["success", "berhasil", "thank you", "terima kasih", "sukses", "welcome", "dashboard"]
ERROR_HINTS = ["error", "gagal", "invalid", "salah", "failed", "tidak valid"]


def load_config(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def field_key(field):
    return field.get("name") or field.get("id") or f"field_{field['index']}"


def get_value_for_field(field, state):
    settings = dict(field.get("settings", {}))
    settings["_field_key"] = field_key(field)
    mode = settings.get("mode", "skip")
    tag = field["tag"]
    ftype = field["type"]

    if mode == "skip":
        return None

    if tag == "select" or ftype in ("radio", "checkbox"):
        if mode == "fixed":
            return settings.get("fixed_value")
        if mode == "random_choice":
            opts = field.get("options") or []
            if not opts:
                return None
            choice = random.choice(opts)
            return choice.get("value")
        return None

    return generators.generate_value(settings, state)


def fill_field(page, field, value):
    if value is None:
        return
    tag = field["tag"]
    ftype = field["type"]
    selector = field["selector"]
    name = field.get("name")

    try:
        if tag == "select":
            page.select_option(selector, value)
        elif ftype in ("checkbox", "radio"):
            sel = f'[name="{name}"][value="{value}"]' if name else selector
            page.check(sel)
        else:
            page.fill(selector, str(value))
    except Exception as e:
        print(f"    [!] Gagal isi field '{name or field.get('id')}': {e}")


def detect_result(page, response_status, detection_cfg):
    manual_success = detection_cfg.get("success_selector")
    manual_error = detection_cfg.get("error_selector")

    if manual_success and page.query_selector(manual_success):
        return "success", "matched success_selector"
    if manual_error and page.query_selector(manual_error):
        return "error", "matched error_selector"

    if detection_cfg.get("auto_detect", True):
        try:
            content = page.content().lower()
        except Exception:
            content = ""
        for hint in SUCCESS_HINTS:
            if hint in content:
                return "success", f"auto-detect keyword '{hint}'"
        for hint in ERROR_HINTS:
            if hint in content:
                return "error", f"auto-detect keyword '{hint}'"

    if response_status is not None:
        if 200 <= response_status < 400:
            return "unknown-ok", f"status {response_status}, no keyword matched"
        return "unknown-fail", f"status {response_status}"

    return "unknown", "no signal detected"


def compute_delay(delay_cfg):
    mode = delay_cfg.get("mode", "none")
    if mode == "none":
        return 0
    if mode == "fixed":
        return float(delay_cfg.get("fixed_seconds", 1))
    if mode == "random":
        lo = float(delay_cfg.get("random_min", 1))
        hi = float(delay_cfg.get("random_max", 3))
        return random.uniform(min(lo, hi), max(lo, hi))
    if mode == "smart":
        return float(delay_cfg.get("fixed_seconds", 1))
    return 0


def run(config, run_count, output_csv):
    url = config["url"]
    fields = config["fields"]
    submit_selector = config.get("submit_selector")
    run_settings = config.get("run_settings", {})
    detection_cfg = config.get("detection", {})
    delay_cfg = run_settings.get("delay", {"mode": "none"})
    session_mode = run_settings.get("session_mode", "new")
    login_required = config.get("login_required", False)

    state = {"sequential": {}, "wordlist": {}}
    results = []
    consecutive_fail_streak = 0

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not login_required)
        storage_state_path = Path("auth_state.json")
        storage_state = str(storage_state_path) if storage_state_path.exists() else None

        if login_required and not storage_state:
            login_ctx = browser.new_context()
            login_page = login_ctx.new_page()
            login_page.goto(url, wait_until="domcontentloaded")
            print("\n[!] Silakan login manual di browser yang terbuka.")
            input("[!] Setelah login selesai, tekan ENTER untuk menyimpan sesi & lanjut...\n")
            login_ctx.storage_state(path=str(storage_state_path))
            storage_state = str(storage_state_path)
            login_ctx.close()

        shared_context = browser.new_context(storage_state=storage_state) if session_mode == "reuse" else None

        i = 0
        endless = run_count is None
        try:
            while endless or i < run_count:
                i += 1
                context = shared_context or browser.new_context(storage_state=storage_state)
                page = context.new_page()

                last_status = {"code": None}

                def on_response(resp, _page=page, _status=last_status):
                    if resp.url == _page.url or resp.request.resource_type == "document":
                        _status["code"] = resp.status

                page.on("response", on_response)

                run_result = {
                    "run": i,
                    "timestamp": datetime.utcnow().isoformat(),
                    "values": {},
                    "result": None,
                    "detail": None,
                    "status_code": None,
                }

                try:
                    page.goto(url, wait_until="domcontentloaded", timeout=30000)

                    for field in fields:
                        value = get_value_for_field(field, state)
                        if value is not None:
                            run_result["values"][field_key(field)] = value
                            fill_field(page, field, value)

                    if submit_selector:
                        page.click(submit_selector)
                    else:
                        page.keyboard.press("Enter")

                    try:
                        page.wait_for_load_state("networkidle", timeout=8000)
                    except PWTimeout:
                        pass

                    status, detail = detect_result(page, last_status["code"], detection_cfg)
                    run_result["result"] = status
                    run_result["detail"] = detail
                    run_result["status_code"] = last_status["code"]

                    consecutive_fail_streak = consecutive_fail_streak + 1 if status in ("error", "unknown-fail") else 0

                except Exception as e:
                    run_result["result"] = "exception"
                    run_result["detail"] = str(e)
                    consecutive_fail_streak += 1

                results.append(run_result)
                print(f"[{i}] {run_result['result']} - {run_result['detail']}")

                if shared_context:
                    page.close()
                else:
                    context.close()

                delay = compute_delay(delay_cfg)
                if delay_cfg.get("mode") == "smart" and consecutive_fail_streak >= 3:
                    delay = max(delay, 5) * consecutive_fail_streak
                    print(f"    [!] Gagal beruntun {consecutive_fail_streak}x, delay diperpanjang jadi {delay:.1f}s")
                if delay > 0:
                    time.sleep(delay)

        except KeyboardInterrupt:
            print("\n[!] Dihentikan oleh pengguna.")

        if shared_context:
            shared_context.close()
        browser.close()

    write_csv(results, output_csv)
    print(f"\n[+] Selesai. Total run: {len(results)}. Log disimpan ke: {output_csv}")


def write_csv(results, path):
    if not results:
        return
    all_field_names = sorted({k for r in results for k in r["values"].keys()})

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["run", "timestamp", "result", "detail", "status_code"] + all_field_names)
        for r in results:
            row = [r["run"], r["timestamp"], r["result"], r["detail"], r["status_code"]]
            row += [r["values"].get(fn, "") for fn in all_field_names]
            writer.writerow(row)


def main():
    ap = argparse.ArgumentParser(description="Jalankan automasi pengisian form (Fase 3).")
    ap.add_argument("--config", default="field_config.json", help="Path field_config.json hasil GUI")
    ap.add_argument("--count", default=None, help="Override jumlah run (angka) atau 'endless'")
    ap.add_argument("--output", default=None, help="Path output CSV log")
    args = ap.parse_args()

    config = load_config(args.config)

    count_arg = args.count or config.get("run_settings", {}).get("count", "10")
    run_count = None if str(count_arg).lower() == "endless" else int(count_arg)

    output_csv = args.output or f"logs/run_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    Path(output_csv).parent.mkdir(parents=True, exist_ok=True)

    run(config, run_count, output_csv)


if __name__ == "__main__":
    main()
